CREATE USER Csucsbiztonsag WITHOUT Login
GRANT SELECT ON Ugyfel TO Csucsbiztonsag