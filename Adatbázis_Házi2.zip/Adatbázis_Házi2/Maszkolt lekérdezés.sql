EXECUTE AS User = 'Csucsbiztonsag'
SELECT * FROM Ugyfel
REVERT